<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/helpers.php';
$formResult = handle_inquiry('contact');
$pageTitle = 'Contact Us | Multi Fix Crew';
$pageDescription = 'Call, WhatsApp, email or send a message to Multi Fix Crew about your property maintenance needs.';
require __DIR__ . '/includes/header.php';
?>
<section class="page-hero contact-hero">
    <div class="container page-hero-grid">
        <div class="reveal"><span class="eyebrow"><i></i> Contact</span><h1>Let’s talk about your space.</h1></div>
        <div class="page-hero-side reveal"><p>Have a question, a repair list or a project in mind? Reach us in the way that suits you.</p></div>
    </div>
</section>

<section class="contact-section section-pad">
    <div class="container">
        <div class="contact-methods">
            <a class="contact-method reveal" href="tel:<?= e(PHONE_LINK) ?>"><span><?= icon('phone') ?></span><small>Call us</small><strong><?= e(PHONE_DISPLAY) ?></strong><i><?= icon('arrow') ?></i></a>
            <a class="contact-method reveal" href="https://wa.me/<?= e(WHATSAPP_NUMBER) ?>" target="_blank" rel="noopener"><span><?= icon('chat') ?></span><small>WhatsApp</small><strong>Start a conversation</strong><i><?= icon('arrow') ?></i></a>
            <a class="contact-method reveal" href="mailto:<?= e(CONTACT_EMAIL) ?>"><span><?= icon('mail') ?></span><small>Email us</small><strong><?= e(CONTACT_EMAIL) ?></strong><i><?= icon('arrow') ?></i></a>
        </div>
        <div class="contact-main">
            <div class="contact-copy reveal"><span class="eyebrow"><i></i> Send a message</span><h2>Not sure which service you need?</h2><p>Describe the issue in your own words. We’ll use your message to understand the right direction.</p><div class="contact-info-row"><?= icon('map') ?><p><strong>Service coverage</strong><small><?= e(SERVICE_AREA) ?></small></p></div><div class="contact-info-row"><?= icon('clock') ?><p><strong>Response</strong><small>We’ll reply as soon as the team is available.</small></p></div></div>
            <div class="form-card contact-form-card reveal">
                <?php if ($formResult['errors']): ?><div class="form-alert" role="alert"><strong>Please check the form:</strong><ul><?php foreach ($formResult['errors'] as $error): ?><li><?= e($error) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
                <form method="post" action="contact.php" class="request-form">
                    <input type="hidden" name="form_type" value="contact"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                    <div class="honeypot" aria-hidden="true"><label>Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
                    <div class="field-grid"><label class="field"><span>Your name *</span><input type="text" name="name" value="<?= e((string) ($_POST['name'] ?? '')) ?>" required autocomplete="name" placeholder="Full name"></label><label class="field"><span>Phone number *</span><input type="tel" name="phone" value="<?= e((string) ($_POST['phone'] ?? '')) ?>" required autocomplete="tel" placeholder="Your best contact number"></label></div>
                    <div class="field-grid"><label class="field"><span>Email address</span><input type="email" name="email" value="<?= e((string) ($_POST['email'] ?? '')) ?>" autocomplete="email" placeholder="you@example.com"></label><label class="field"><span>Area / community</span><input type="text" name="location" value="<?= e((string) ($_POST['location'] ?? '')) ?>" placeholder="Where is the property?"></label></div>
                    <label class="field"><span>Related service</span><select name="service"><option value="">General question</option><?php foreach ($services as $slug => $service): ?><option value="<?= e($slug) ?>"<?= (($_POST['service'] ?? '') === $slug) ? ' selected' : '' ?>><?= e($service['name']) ?></option><?php endforeach; ?></select></label>
                    <label class="field"><span>Your message *</span><textarea name="message" rows="6" required minlength="10" maxlength="3000" placeholder="How can we help?"><?= e((string) ($_POST['message'] ?? '')) ?></textarea></label>
                    <button class="button button-primary button-submit" type="submit">Send message <?= icon('arrow', 'button-icon') ?></button>
                    <p class="form-privacy">By sending this form, you agree to our <a href="privacy.php">privacy policy</a>.</p>
                </form>
            </div>
        </div>
    </div>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>

